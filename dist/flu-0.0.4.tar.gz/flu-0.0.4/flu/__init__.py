# __init__.py

# Version of the flu package
__version__ = "0.0.4"