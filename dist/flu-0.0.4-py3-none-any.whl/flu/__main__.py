"""flu.__main__: executed when flu directory is called as script."""

from .flu import main

main()